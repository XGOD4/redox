
python redox.py [site] [username] [wordlist]

python redox.py Instagram username pass.lst

[-] Is not supported by developer anymore.